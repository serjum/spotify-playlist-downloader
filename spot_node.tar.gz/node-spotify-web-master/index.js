module.exports = require('./lib/spotify');
